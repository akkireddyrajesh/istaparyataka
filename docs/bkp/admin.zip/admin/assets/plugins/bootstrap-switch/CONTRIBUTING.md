If you want help us to fix bugs or add a extension please use our develop branch




https://github.com/nostalgiaz/bootstrap-switch/tree/develop


First step:

Please merge your branch develop with nostalgiaz/bootstrap-switch/tree/develop


second step:

Work in the branch develop for fixes


third step:

regularly reviews the branch develop for updates and then merge this with your branch develop


fourth step:

When you're done in your branch send us a PR to merge the two branches
