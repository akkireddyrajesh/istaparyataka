<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
| example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
| https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
| $route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the 'welcome' class
| would be loaded.
|
| $route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
| $route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples: my-controller/index -> my_controller/index
|   my-controller/my-method -> my_controller/my_method
*/
$route['default_controller'] = 'welcome';
$route['404_override'] = '';
$route['translate_uri_dashes'] = TRUE;

# Migration endpoint - root db
$route['migrate/db'] = 'api/Migrate/index'; // GET Method

# Users endpoints
$route['api/user/register'] = 'api/UsersController/register'; // POST Method
$route['api/user/login'] = 'api/UsersController/login'; // POST Method
$route['api/user/update/(:num)'] = 'api/UsersController/update/$1'; // PUT Method
$route['api/user/changePassword'] = 'api/UsersController/changePassword'; // POST Method
$route['api/users/logout'] = 'api/UsersController/logout'; // GET Method
$route['api/users'] = 'api/UsersController/fetch'; // GET Method
$route['api/users/loginCreate'] = 'api/UsersController/loginCreate'; // POST Method
$route['api/users/updatePin/(:num)'] = 'api/UsersController/updatePin/$1'; // POST Method

# Role Endpoints
$route['api/roles'] = 'api/RoleController/fetch'; // GET Method
$route['api/roles/create'] = 'api/RoleController/create'; // POST Method
$route['api/roles/update/(:num)'] = 'api/RoleController/update/$1'; // PUT Method
$route['api/roles/delete/(:num)'] = 'api/RoleController/delete/$1'; // DELETE Method
$route['api/roles/search'] = 'api/RoleController/search'; // GET Method

# Category Endpoints
$route['api/category'] = 'api/CategoryController/fetch'; // GET Method
$route['api/category/create'] = 'api/CategoryController/create'; // POST Method
$route['api/category/update/(:num)'] = 'api/CategoryController/update/$1'; // PUT Method
$route['api/category/delete/(:num)'] = 'api/CategoryController/delete/$1'; // DELETE Method
$route['api/category/search'] = 'api/CategoryController/search'; // GET Method

# products Endpoints
$route['api/products'] = 'api/ProductController/fetch'; // GET Method
$route['api/products/create'] = 'api/ProductController/create'; // POST Method
$route['api/products/update/(:num)'] = 'api/ProductController/update/$1'; // PUT Method
$route['api/products/delete/(:num)'] = 'api/ProductController/delete/$1'; // DELETE Method
$route['api/products/search'] = 'api/ProductController/search'; // GET Method

# Order Endpoints
$route['api/orders'] = 'api/OrderController/fetch'; // GET Method
$route['api/orders/create'] = 'api/OrderController/create'; // POST Method
$route['api/orders/update/(:num)'] = 'api/OrderController/update/$1'; // PUT Method
$route['api/orders/delete/(:num)'] = 'api/OrderController/delete/$1'; // DELETE Method
$route['api/orders/search'] = 'api/OrderController/search'; // GET Method

# Inventory Endpoints
$route['api/inventory'] = 'api/InventoryController/fetch'; // GET Method
$route['api/inventory/create'] = 'api/InventoryController/create'; // POST Method
$route['api/inventory/update/(:num)'] = 'api/InventoryController/update/$1'; // PUT Method
$route['api/inventory/delete/(:num)'] = 'api/InventoryController/delete/$1'; // DELETE Method
$route['api/inventory/search'] = 'api/InventoryController/search'; // GET Method