<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . 'libraries/REST_Controller.php';

/**
 * Users Controller
 */
class UsersController extends REST_Controller
{
  # Construct the parent class
  public function __construct() {
    parent::__construct();
    # Load model
    $this->load->model('UsersModel');
    $this->load->model('LibraryModel');

  }

#
########################################################################################################
#

  /**
   * Method : POST
   * Method Name : register
   * 
   * @return  array response
   */
  public function register_post()
  {
    # Validate HTTP Request "Content-type"
    if (!preg_match('/application\/json/i',($this->input->get_request_header('Content-Type') ?? ''))) {
      return $this->set_response(['status'=>'fail', 'code'=>'0', 'message'=>'Bad Request', 'details'=>'Content-Type must be application-json'], REST_Controller::HTTP_BAD_REQUEST);
    }

    # Decode payload to array - get post body
    $input = (json_decode(file_get_contents('php://input'),true) ?? []);
    if (empty($input)) {
      return $this->set_response(['status'=>'fail', 'code'=>'0', 'message'=>'Bad Request', 'details'=>'Invalid post body'], REST_Controller::HTTP_BAD_REQUEST);
    }

    # user_mobile exist check
    if(empty($input['user_phone_number'])) {
      return $this->set_response(['status'=>'fail', 'code'=>'0', 'message'=>'Bad Request', 'details'=>'Mobile Number is a mandatory field'], REST_Controller::HTTP_BAD_REQUEST);
    }

    # Send request to model - returns an array
    $result=$this->UsersModel->register($input);
    
    # Set error message if found
    if(isset($result['message'])) {
      # NOT_FOUND (404) being the HTTP response code
      return $this->set_response(['status' => 'fail', 'code' => '0', 'message' => $result['message']], REST_Controller::HTTP_NOT_FOUND);
    }

	  # Set (200) OK being the HTTP response code & return an array
    $this->set_response(['status' => 'success', 'code' => '1', 'data' =>$result], REST_Controller::HTTP_CREATED);
  }

#
########################################################################################################
#

  /**
   * Method : POST
   * Method Name : login
   * Description : login with email & password
   * 
   * POST BODY : Json Body
   * {
   *    "user_email":"",
   *    "user_password":""
   * }
   * 
   * @return  array response
   */
  public function login_post()
  {
    # Validate HTTP Request "Content-type"
    if (!preg_match('/application\/json/i',($this->input->get_request_header('Content-Type') ?? ''))) {
      return $this->set_response(['status'=>'fail', 'code'=>'0', 'message'=>'Bad Request', 'details'=>'Content-Type must be application-json'], REST_Controller::HTTP_BAD_REQUEST); 
    }   
    
    # Decode payload to array - get post body 
    $input = (json_decode(file_get_contents('php://input'),true) ?? []);
    if (empty($input)) {
      return $this->set_response(['status'=>'fail', 'code'=>'0', 'message'=>'Bad Request', 'details'=>'Invalid post body'], REST_Controller::HTTP_BAD_REQUEST);
    }
    
    # user_email exist check
    if(empty($input['user_phone_number'])) {
      return $this->set_response(['status'=>'fail', 'code'=>'0', 'message'=>'Bad Request', 'details'=>'user_phone_number is a mandatory field'], REST_Controller::HTTP_BAD_REQUEST);
    }
    
    # user_password exist check
    if(empty($input['user_password'])) {
      return $this->set_response(['status'=>'fail', 'code'=>'0', 'message'=>'Bad Request', 'details'=>'user_password is a mandatory field'], REST_Controller::HTTP_BAD_REQUEST);
    }

    # Send request to model - returns an array
    $result=$this->UsersModel->login($input);

    # Set error message if found
    if(isset($result['message'])) {
      # NOT_FOUND (404) being the HTTP response code
      return $this->set_response(['status' => 'fail', 'code' => '0', 'message' => $result['message']], REST_Controller::HTTP_NOT_FOUND); 
    }

		# Set (200) OK being the HTTP response code & return an array
    $this->set_response(['status' => 'success', 'code' => '1', 'data' =>$result], REST_Controller::HTTP_CREATED);
  }

#
########################################################################################################
#

  /**
   * Method : PUT
   * Method Name : update
   * Description : update a existing record
   *  
   * @return  array response
   */
  public function update_put($id)
  {
    # Header Check - Content-Type : Application / Json
    if (!preg_match('/application\/json/i',($this->input->get_request_header('Content-Type') ?? ''))) {
      return $this->set_response(['status'=>'fail', 'code'=>'0', 'message'=>'Bad Request', 'details'=>'Content-Type must be application-json'], REST_Controller::HTTP_BAD_REQUEST);
    }

    # Get Token & Explode $token to get token & key
    $token = $this->input->get_request_header('Authorization') ?? '';
    $data = explode(" ", $token);

    # Validate 'Authorization' exist check
    if ( (empty($token)) || (strtolower($data[0]) !== "token") || (empty($data[1])) ) {
      return $this->set_response(['status'=>'fail', 'code'=>'0', 'message'=>'Bad Request', 'details'=>'Authorization Token Is Missing'], REST_Controller::HTTP_BAD_REQUEST);
    }

    # Verify token & get user data
    $user = (new LibraryModel())->verifyToken($data[1]);
    if(isset($user['message'])) {
      # NOT_FOUND (404) being the HTTP response code
      return $this->set_response(['status' => 'fail', 'code' => '0', 'message' => $user['message']], REST_Controller::HTTP_NOT_FOUND); 
    }

    # Decode payload to array - get post body 
    $input = (json_decode(file_get_contents('php://input'),true) ?? []);
    if (empty($input)) {
      return $this->set_response(['status'=>'fail', 'code'=>'0', 'message'=>'Bad Request', 'details'=>'Invalid post body'], REST_Controller::HTTP_BAD_REQUEST);
    }

    # Send request to model - returns an array
    $result=$this->UsersModel->update($id, $input);

    # Set error message if found
    if(isset($result['message'])) {
      # NOT_FOUND (404) being the HTTP response code
      $this->set_response(['status' => FALSE, 'code' => '0', 'message' => $result['message']], REST_Controller::HTTP_NOT_FOUND);
    }

		# Set (200) OK being the HTTP response code & return an array
    $this->set_response($result, REST_Controller::HTTP_CREATED);
  }


#
########################################################################################################
#

  /**
   * Method : PUT
   * Method Name : update
   * Description : update a existing record
   *  
   * @return  array response
   */
  public function updatePin_put($id)
  {
    # Header Check - Content-Type : Application / Json
    if (!preg_match('/application\/json/i',($this->input->get_request_header('Content-Type') ?? ''))) {
      return $this->set_response(['status'=>'fail', 'code'=>'0', 'message'=>'Bad Request', 'details'=>'Content-Type must be application-json'], REST_Controller::HTTP_BAD_REQUEST);
    }

    # Get Token & Explode $token to get token & key
    $token = $this->input->get_request_header('Authorization') ?? '';
    $data = explode(" ", $token);

    # Validate 'Authorization' exist check
    if ( (empty($token)) || (strtolower($data[0]) !== "token") || (empty($data[1])) ) {
      return $this->set_response(['status'=>'fail', 'code'=>'0', 'message'=>'Bad Request', 'details'=>'Authorization Token Is Missing'], REST_Controller::HTTP_BAD_REQUEST);
    }

    # Verify token & get user data
    $user = (new LibraryModel())->verifyToken($data[1]);
    if(isset($user['message'])) {
      # NOT_FOUND (404) being the HTTP response code
      return $this->set_response(['status' => 'fail', 'code' => '0', 'message' => $user['message']], REST_Controller::HTTP_NOT_FOUND); 
    }

    # Decode payload to array - get post body 
    $input = (json_decode(file_get_contents('php://input'),true) ?? []);
    if (empty($input)) {
      return $this->set_response(['status'=>'fail', 'code'=>'0', 'message'=>'Bad Request', 'details'=>'Invalid post body'], REST_Controller::HTTP_BAD_REQUEST);
    }

    # Send request to model - returns an array
    $result=$this->UsersModel->updatePin($id, $input);

    # Set error message if found
    if(isset($result['message'])) {
      # NOT_FOUND (404) being the HTTP response code
      $this->set_response(['status' => FALSE, 'code' => '0', 'message' => $result['message']], REST_Controller::HTTP_NOT_FOUND);
    }

		# Set (200) OK being the HTTP response code & return an array
    $this->set_response($result, REST_Controller::HTTP_CREATED);
  }



#
########################################################################################################
#

  /**
   * Method : GET
   * Method Name : fetch
   * Description : fetch all records based on params
   * 
   * @param   array List of params
   * 
   * NOTE : PAGINATION INFORMATION
   * @param   string    limit - no of records to show
   * @param   string    start - from where to show (starting point)
   * 
   * @return  array response
   */
  public function fetch_get()
  {
    # Header Check - Content-Type : Application / Json
    if (!preg_match('/application\/json/i',($this->input->get_request_header('Content-Type') ?? ''))) {
      return $this->set_response(['status'=>'fail', 'code'=>'0', 'message'=>'Bad Request', 'details'=>'Content-Type must be application-json'], REST_Controller::HTTP_BAD_REQUEST);
    }

    # Get Token & Explode $token to get token & key
    $token = $this->input->get_request_header('Authorization') ?? '';
    $data = explode(" ", $token);

    # Validate 'Authorization' exist check
    if ( (empty($token)) || (strtolower($data[0]) !== "token") || (empty($data[1])) ) {
      return $this->set_response(['status'=>'fail', 'code'=>'0', 'message'=>'Bad Request', 'details'=>'Authorization Token Is Missing'], REST_Controller::HTTP_BAD_REQUEST);
    }

    # Verify token & get user data
    $user = (new LibraryModel())->verifyToken($data[1]);
    if(isset($user['message'])) {
      # NOT_FOUND (404) being the HTTP response code
      return $this->set_response(['status' => 'fail', 'code' => '0', 'message' => $user['message']], REST_Controller::HTTP_NOT_FOUND); 
    }

    # Get Params
    $params = [
      'id'=>$this->get('id') ?? '',
      'user_email'=>$this->get('user_email') ?? '',
      'limit'=>$this->get('limit') ?? '',
      'start'=>$this->get('start') ?? ''
    ];

    # Send request to model - returns an array
    $result=$this->UsersModel->fetch($params);

    # Set error message if found
    if(isset($result['message'])) {
      # NOT_FOUND (404) being the HTTP response code
      return $this->set_response(['status' => 'fail', 'code' => '0', 'message' => $result['message']], REST_Controller::HTTP_NOT_FOUND);
    }

		# Set (200) OK being the HTTP response code & return an array
    $this->set_response(['status' => 'success', 'code' => '1', 'data' => $result], REST_Controller::HTTP_OK);
  }
  
#
########################################################################################################
#

  /**
   * Method : POST
   * Method Name : changePassword
   * Description : Change Password
   * 
   * POST BODY : Json Body
   * {
   *    "old_password":"",
   *    "new_password":"",
   *    "repeat_password":""
   * }
   * 
   * @return  array response
   */
  public function changePassword_post()
  {
    # Header Check - Content-Type : Application / Json
    if (!preg_match('/application\/json/i',($this->input->get_request_header('Content-Type') ?? ''))) {
      return $this->set_response(['status'=>'fail', 'code'=>'0', 'message'=>'Bad Request', 'details'=>'Content-Type must be application-json'], REST_Controller::HTTP_BAD_REQUEST);
    }

    # Get Token & Explode $token to get token & key
    $token = $this->input->get_request_header('Authorization') ?? '';
    $data = explode(" ", $token);

    # Validate 'Authorization' exist check
    if ( (empty($token)) || (strtolower($data[0]) !== "token") || (empty($data[1])) ) {
      return $this->set_response(['status'=>'fail', 'code'=>'0', 'message'=>'Bad Request', 'details'=>'Authorization Token Is Missing'], REST_Controller::HTTP_BAD_REQUEST);
    }

    # Verify token & get user data
    $user = (new LibraryModel())->verifyToken($data[1]);
    if(isset($user['message'])) {
      # NOT_FOUND (404) being the HTTP response code
      return $this->set_response(['status' => 'fail', 'code' => '0', 'message' => $user['message']], REST_Controller::HTTP_NOT_FOUND); 
    }
    
    # Decode payload to array - get post body 
    $input = (json_decode(file_get_contents('php://input'),true) ?? []);
    if (empty($input)) {
      return $this->set_response(['status'=>'fail', 'code'=>'0', 'message'=>'Bad Request', 'details'=>'Invalid post body'], REST_Controller::HTTP_BAD_REQUEST);
    }
    
    # old_password exist check
    if(empty($input['old_password'])) {
      return $this->set_response(['status'=>'fail', 'code'=>'0', 'message'=>'Bad Request', 'details'=>'old_password is a mandatory field'], REST_Controller::HTTP_BAD_REQUEST);
    }
    
    # new_password exist check
    if(empty($input['new_password'])) {
      return $this->set_response(['status'=>'fail', 'code'=>'0', 'message'=>'Bad Request', 'details'=>'new_password is a mandatory field'], REST_Controller::HTTP_BAD_REQUEST);
    }

    # repeat_password exist check
    if(empty($input['repeat_password'])) {
      return $this->set_response(['status'=>'fail', 'code'=>'0', 'message'=>'Bad Request', 'details'=>'repeat_password is a mandatory field'], REST_Controller::HTTP_BAD_REQUEST);
    }
    
    # Send request to model - returns an array
    $result=$this->UsersModel->changePassword($input, $user, $data[1]);

    # Set error message if found
    if(isset($result['message'])) {
      # NOT_FOUND (404) being the HTTP response code
      return $this->set_response(['status' => FALSE, 'code' => '0', 'message' => $result['message']], REST_Controller::HTTP_NOT_FOUND); 
    }

	  # Set (200) OK being the HTTP response code & return an array
    $this->set_response($result, REST_Controller::HTTP_CREATED);
  }

#
########################################################################################################
#

  /**
   * Method : POST
   * Method Name : Logout
   * Description : Logout
   *  
   * @return  array response
   */
  public function logout_get()
  {
    # Header Check - Content-Type : Application / Json
    if (!preg_match('/application\/json/i',($this->input->get_request_header('Content-Type') ?? ''))) {
      return $this->set_response(['status'=>'fail', 'code'=>'0', 'message'=>'Bad Request', 'details'=>'Content-Type must be application-json'], REST_Controller::HTTP_BAD_REQUEST);
    }

    # Get Token & Explode $token to get token & key
    $token = $this->input->get_request_header('Authorization') ?? '';
    $data = explode(" ", $token);

    # Validate 'Authorization' exist check
    if ( (empty($token)) || (strtolower($data[0]) !== "token") || (empty($data[1])) ) {
      return $this->set_response(['status'=>'fail', 'code'=>'0', 'message'=>'Bad Request', 'details'=>'Authorization Token Is Missing'], REST_Controller::HTTP_BAD_REQUEST);
    }

    # Verify token & get user data
    $user = (new LibraryModel())->verifyToken($data[1]);
    if(isset($user['message'])) {
      # NOT_FOUND (404) being the HTTP response code
      return $this->set_response(['status' => 'fail', 'code' => '0', 'message' => $user['message']], REST_Controller::HTTP_NOT_FOUND); 
    }
    
    # Send request to model - returns an array
    $result=$this->UsersModel->logout($user, $data[1]);

    # Set error message if found
    if(isset($result['message'])) {
      # NOT_FOUND (404) being the HTTP response code
      $this->set_response(['status' => FALSE, 'code' => '0', 'message' => $result['message']], REST_Controller::HTTP_NOT_FOUND); 
    }

	  # Set (200) OK being the HTTP response code & return an array
    $this->set_response($result, REST_Controller::HTTP_CREATED);
  }

  #
########################################################################################################
#

  /**
   * Method : POST
   * Method Name : login
   * Description : login with email & password
   * 
   * POST BODY : Json Body
   * {
   *    "user_email":"",
   *    "user_password":""
   * }
   * 
   * @return  array response
   */
  public function loginCreate_post()
  {
    # Validate HTTP Request "Content-type"
    if (!preg_match('/application\/json/i',($this->input->get_request_header('Content-Type') ?? ''))) {
      return $this->set_response(['status'=>'fail', 'code'=>'0', 'message'=>'Bad Request', 'details'=>'Content-Type must be application-json'], REST_Controller::HTTP_BAD_REQUEST); 
    }   
    
    # Decode payload to array - get post body 
    $input = (json_decode(file_get_contents('php://input'),true) ?? []);
    if (empty($input)) {
      return $this->set_response(['status'=>'fail', 'code'=>'0', 'message'=>'Bad Request', 'details'=>'Invalid post body'], REST_Controller::HTTP_BAD_REQUEST);
    }
    
    # user_email exist check
    if(empty($input['user_phone_number'])) {
      return $this->set_response(['status'=>'fail', 'code'=>'0', 'message'=>'Bad Request', 'details'=>'user_phone_number is a mandatory field'], REST_Controller::HTTP_BAD_REQUEST);
    }

    # Send request to model - returns an array
    $result=$this->UsersModel->loginCreate($input);

    # Set error message if found
    if(isset($result['message'])) {
      # NOT_FOUND (404) being the HTTP response code
      return $this->set_response(['status' => 'fail', 'code' => '0', 'message' => $result['message']], REST_Controller::HTTP_NOT_FOUND); 
    }

		# Set (200) OK being the HTTP response code & return an array
    $this->set_response(['status' => 'success', 'code' => '1', 'data' =>$result], REST_Controller::HTTP_CREATED);
  }

}