<?php
  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

  class guzzle {
    public function index() {
      // require_once('vendor/autoload.php');
      require 'vendor/autoload.php';
    }
  }
?>  
