<?php defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_Create_edit_phone_messages_table
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_Create_edit_phone_messages_table extends CI_Migration
{
  public function up()
  {
    $this->dbforge->add_field(
    array(
      'id'  =>  array(
        'type'  =>  'INT',
        'auto_increment'  =>  TRUE,
      ),
      'phone_message_id'  =>  array(
        'type'  =>  'INT',
      ),
      'language_id'  =>  array(
        'type'  =>  'INT',
      ),
      'sms_test'  =>  array(
        'type'  =>  'TEXT',
      ),
      'message_id'  =>  array(
        'type'  =>  'INT',
      ),
      'wav_message_file'  =>  array(
        'type'  =>  'VARCHAR',
        'constraint'  =>  '512',
      ),
      'heard_status'  =>  array(
        'type'  =>  'VARCHAR',
        'constraint'  =>  '255',
      ),
      'problem_type_id'  =>  array(
        'type'  =>  'INT',
      ),
      'description'  =>  array(
        'type'  =>  'TEXT',
      ),
      'complaint_document_file'  =>  array(
        'type'  =>  'VARCHAR',
        'constraint'  =>  '512',
      ),
      'assistant_user_id'  =>  array(
        'type'  =>  'INT',
      ),
      'assign_category_id'  =>  array(
        'type'  =>  'INT',
      ),
      'date_for_follow_up'  =>  array(
        'type'  =>  'DATE',
      ),
      'officers_list_id'  =>  array(
        'type'  =>  'INT',
      ),
      'department_list_id'  =>  array(
        'type'  =>  'INT',
      ),
      'message_status_id'  =>  array(
        'type'  =>  'INT',
      ),
      'reffered_to'  =>  array(
        'type'  =>  'VARCHAR',
        'constraint'  =>  '255',
      ),
      'follow_up_action'  =>  array(
        'type'  =>  'VARCHAR',
        'constraint'  =>  '255',
      ),
      'response'  =>  array(
        'type'  =>  'VARCHAR',
        'constraint'  =>  '255',
      ),
      'citizen_name'  =>  array(
        'type'  =>  'VARCHAR',
        'constraint'  =>  '255',
      ),
      'citizen_mobile_id'  =>  array(
        'type'  =>  'VARCHAR',
        'constraint'  =>  '255',
      ),
      'citizen_picture_file'  =>  array(
        'type'  =>  'VARCHAR',
        'constraint'  =>  '512',
      ),
      'voter_id'  =>  array(
        'type'  =>  'VARCHAR',
        'constraint'  =>  '255',
      ),
      'citizen_aadhaar_number'  =>  array(
        'type'  =>  'VARCHAR',
        'constraint'  =>  '255',
      ),
      'citizen_pincode'  =>  array(
        'type'  =>  'VARCHAR',
        'constraint'  =>  '255',
      ),
      'citizen_location'  =>  array(
        'type'  =>  'VARCHAR',
        'constraint'  =>  '255',
      ),
      'booth_number'  =>  array(
        'type'  =>  'VARCHAR',
        'constraint'  =>  '255',
      ),
      'booth_location'  =>  array(
        'type'  =>  'VARCHAR',
        'constraint'  =>  '255',
      ),
      'modified_dt'  =>  array(
        'type'  =>  'DATETIME',
      ),
    ));

    $this->dbforge->add_key('id', TRUE);
    $this->dbforge->create_table('edit_phone_messages');
  }

  public function down()
  {
    // $this->dbforge->drop_table('edit_phone_messages');
  }

}