<?php
if(! defined('BASEPATH')) exit ('No direct script access allowed');

class LibraryModel extends CI_Model {

  public function __construct(){
    parent::__construct();
    $this->table  = 'users';
    $this->table1 = 'sessions';
    $this->table2 = 'jwt_tokens';
  }

  /**
   * Method Name : UUID
   * Description : Generate our own uuid's
   * 
   * @param   boolean   $trim - false
   * 
   * @return  string    UUID
   */
  public function UUID($trim = false)
  {
    # Format
    $format = ($trim == false) ? '%04x%04x-%04x-%04x-%04x-%04x%04x%04x' : '%04x%04x%04x%04x%04x%04x%04x%04x';

    # generate UUID
    $uuid = sprintf($format,
      # 32 bits for "time_low"
      mt_rand(0, 0xffff), mt_rand(0, 0xffff),
      # 16 bits for "time_mid"
      mt_rand(0, 0xffff),
      # 16 bits for "time_hi_and_version", four most significant bits holds version number 4
      mt_rand(0, 0x0fff) | 0x4000,
      # 16 bits, 8 bits for "clk_seq_hi_res", 8 bits for "clk_seq_low", two most significant bits holds zero and one for variant DCE1.1
      mt_rand(0, 0x3fff) | 0x8000,
      # 48 bits for "node"
      mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
    
    return $uuid ?? "";
  }

  /**
   * Method Name : createSession
   * Description : create a session to the user
   * 
   * @param   string    $private_uuid   of the user
   * 
   * @return  array     Response
   */
  public function createSession(string $id) 
  {
    # Force some Body parameters
    $session_id = password_hash( $this->LibraryModel->UUID(), PASSWORD_BCRYPT);

    # Create array
    $data=array(
      'session_id'=>$session_id,
      'user_id'=>$id,
      'created_dt'=>date('Y-m-d H:i:s'),
      'expires_dt'=>date('Y-m-d H:i:s'),
      'client_ip4'=>$_SERVER['REMOTE_ADDR'],
      // 'client_ipv4'=>'',
      'meta'=>""
   );

    # Initialize array
    $result = [];

    # Insert data
    $insert = $this->db->insert($this->table1,$data);
    if($insert) {
     $id = $this->db->insert_id();
      $result = $this->db->select('session_id')->from($this->table1)->where('id', $id)->get()->row_array() ?? [];
    }

    return $result;
  }

  /**
   * Method Name : createToken
   * Description : create a token to the user
   * 
   * @param   string    $private_uuid   of the user
   * 
   * @param   string    $session_id   of the user
   * 
   * @return  array     Response
   */
  public function createToken($session_id)
  {
    # Force some Body parameters
    $jwt_token = md5(uniqid(rand(), true)).md5(uniqid(rand(), true)).md5(uniqid(rand(), true));

    # Create array
   $data=array(
      'session_id'=>$session_id,
      'jwt_token'=>$jwt_token,
      'created_dt'=>date('Y-m-d H:i:s')
    );

    # Initialize array
    $result = [];

    # Insert data
    $insert = $this->db->insert($this->table2,$data);
    if($insert) {
      $id = $this->db->insert_id();
      $result = $this->db->select('jwt_token')->from($this->table2)->where('id', $id)->get()->row_array();
   }

    return $result;
  }

  /**
   * Method Name : verifyToken
   * Description : Verify jwt-token & expiry date
   * 
   * @param   string  $jwt_token
   * 
   * @return  array   response
   */
  public function verifyToken(string $jwt_token) 
  {
    # Initialize array
    $result = [];

    # Get jwt token data
    $jwtToken = $this->db->select('*')->from($this->table2)->where('jwt_token', $jwt_token)->get()->row_array() ?? [];
    if(empty($jwtToken)) {
      $result['message'] = "Failed To Authenticate User Session!";
      return $result;
    }

    # Get session
    $session = $this->db->select('*')->from($this->table1)->where('session_id', $jwtToken['session_id'])->get()->row_array() ?? [];
    if(empty($session)) {
      $result['message'] = "Failed To Authenticate User Session!";
      return $result;
    }
    
    # Get Auth User Data
    $user = $this->db->select('*')->from($this->table)->where('id', $session['user_id'])->get()->row_array() ?? [];
    if(empty($session)) {
      $result['message'] = "Failed To Authenticate User Session!";
      return $result;
    }

    return $user;
  }
  
  /**
   * Method Name : getAuthUser
   * Description : Verify jwt-token & get user data
   * 
   * @param   string  $key
   * 
   * @return  array   $user User-Data
   */
  public function getAuthUser(string $key) 
  {
    # Initialize array
    $user = [];

    # Get jwt token data
    $jwtToken = $this->db->select('*')->from($this->table2)->where('jwt_token', $key)->get()->row_array() ?? [];
    if(empty($jwtToken)) return $jwtToken;

    # Get Auth User Data
    $user = $this->db->select('id, user_name, user_email, user_mobile, created_dt, user_zipcode, user_image, state_id, role_code, role_name')->from($this->table)->where('private_uuid', $jwtToken['user_uuid'])->get()->row_array() ?? [];
    if(empty($user)) return $user;

    return $user;
  }

  /**
   * Method Name : createDynamicDb
   * Description : Dynamic Creation Of Db
   * 
   * @param   array     $dbCredentials   Db Data
   *
   * @param   string     $filePath   database file
   * 
   * @return  boolean   TRUE / FALSE
   */
  public function createDynamicDb(array $dbCredentials, $filePath) 
  {
    # Create Db
    $this->dbforge->create_database($dbCredentials['database_name']);

    # Initialise Variables
    $var = "$";

    # Initialise Strings
    $config = "";

    # Create string
    $config .= PHP_EOL.PHP_EOL;
    $config .= "# User Dynamic Database - Dynamic Db : ".$dbCredentials['database_name'].PHP_EOL;
    $config .= $var."db['".$dbCredentials['database_name']."'] = array(".PHP_EOL;
    $config .= "	'dsn'	=> '',".PHP_EOL;
    $config .= "	'hostname' => '".$dbCredentials['database_hostname']."',".PHP_EOL;
    $config .= "	'username' => '".$dbCredentials['database_username']."',".PHP_EOL;
    $config .= "	'password' => '".$dbCredentials['database_password']."',".PHP_EOL;
    $config .= "	'database' => '".$dbCredentials['database_name']."',".PHP_EOL;
    $config .= "	'dbdriver' => 'mysqli',".PHP_EOL;
    $config .= "	'dbprefix' => '',".PHP_EOL;
    $config .= "	'pconnect' => FALSE,".PHP_EOL;
    $config .= "	'db_debug' => (ENVIRONMENT !== 'production'),".PHP_EOL;
    $config .= "	'cache_on' => FALSE,".PHP_EOL;
    $config .= "	'cachedir' => '',".PHP_EOL;
    $config .= "	'char_set' => 'utf8',".PHP_EOL;
    $config .= "	'dbcollat' => 'utf8_general_ci',".PHP_EOL;
    $config .= "	'swap_pre' => '',".PHP_EOL;
    $config .= "	'encrypt' => FALSE,".PHP_EOL;
    $config .= "	'compress' => FALSE,".PHP_EOL;
    $config .= "	'stricton' => FALSE,".PHP_EOL;
    $config .= "	'failover' => array(),".PHP_EOL;
    $config .= "	'save_queries' => TRUE".PHP_EOL;
    $config .= ");".PHP_EOL;

    # Create Routes File & Copy Content
    file_put_contents($filePath, $config.PHP_EOL, FILE_APPEND | LOCK_EX);

    return TRUE;
  }

}
?>
