<?php
if(! defined('BASEPATH')) exit ('No direct script access allowed');

class OrderModel extends CI_Model {

  public function __construct(){
      parent::__construct();
      $this->table = 'orders';
      $this->load->model('LibraryModel');
      $this->load->model('UsersModel');
      $this->table1 = 'inventory';

  }

  /**
   * Method Name : fetch
   * Description : fetch all records based on params
   * 
   * @param  array $params List of params
   * 
   * @return  array response
   */
  public function fetch($params)
  {
    # Query builder
    $this->db->select('*')->from($this->table);

    # id
    if(strlen($params['id']) > 0) $this->db->where('id', $params['id']);

    # user_id
    if(strlen($params['user_id']) > 0) $this->db->where('user_id', $params['user_id']);

    # location_id
    if(isset($params['location_id']) && strlen($params['location_id']) > 0) $this->db->where('location_id', $params['location_id']);

    # ordered_status
    if(isset($params['ordered_status']) && strlen($params['ordered_status']) > 0) $this->db->where('ordered_status', $params['ordered_status']);

    # Pagination
    if( isset($params['limit']) && isset($params['start']) && strlen($params['limit']) > 0 && strlen($params['start']) > 0) $this->db->limit($params['limit'], $params['start']);

    # result query
    $query = $this->db->get()->result();

    # Initialize array
    $data = [];

    # foreach all records
    foreach($query as $item) {
      $item['ordered_status'] = json_encode($item['ordered_status']);
      $item->user = $this->UserModel->fetch(['id'=>$item['user_id']]);
      $data[] = $item;
    }

    return $data;
  }

#
########################################################################################################
#

  /**
   * Method Name : create
   * Description : create a new record
   * 
   * @param  array $input post body
   * 
   * @return  array response
   */
  public function create(array $input)
  {
    # Create array
    $data=array(
      'ordered_products'=>json_encode($input['ordered_products']),
      'user_id'=>$input['user_id'],
      'location_id'=>$input['location_id'],
      'ordered_status'=>$input['ordered_status'],
      'delivery_address'=>$input['delivery_address'],
      'created_dt'=>date('Y-m-d H:i:s'),
      'modified_dt'=>date('Y-m-d H:i:s')
    );
    # Initialize array
    $result = false;

    $insert = $this->db->insert($this->table,$data);
    if($insert) {
      $insertedId = $this->db->insert_id();
      $updateInventory = $this->updateInventoryByOrders($input['ordered_products']);
      //  $result = $this->fetch(['id' => $insertedId]);
      $result = true;
    } else {
      $result['message'] = 'Failed To Add New Record';
    }
    return $result;
  }

  public function updateInventoryByOrders ($orderedData) {
    foreach ($orderedData as $item) {
      $orginalData = $this->db->select('*')->from($this->table1)->where('product_id',$item['product_id'])->get()->row_array();
      if (!empty($orginalData)) {
        if ($orginalData['product_qty'] != 0) {
            $updatedQty = $orginalData['product_qty'] - $item['qty'];
            $updatedData = array(
              'product_qty' => $updatedQty
            );
            $this->db->where('id',$orginalData['id']);
            $this->db->update($this->table1,  $updatedData);
        }
      }
    }
  }

#
########################################################################################################
#

  /**
   * Method Name : update
   * Description : update a existing record
   * 
   * @param  int  $id       ID
   * 
   * @param  array   $input    post body
   * 
   * @return  array response
   */
  public function update(string $id, array $input)
  {

    # Initialize array
    $result = [];

    # Check id exist
    $entity = $this->fetch(['id'=>$id]);

    # Error check if no record found with given ID
    if(empty($entity)) {
      $data['message']='No Record Found With This ID';
    }

    # Create array
    $data=array(
      // 'ordered_products'=>json_encode($input['ordered_products']),
      // 'user_id'=>$input['user_id'],
      // 'location_id'=>$input['location_id'],
      'ordered_status'=>$input['ordered_status'],
      // 'modified_dt'=>date('Y-m-d H:i:s')
    );


    # Update data
    $update = $this->db->where('id',$id)->update($this->table, $data);

    # Error check if failed to update
    if(!$update) {
      $result['message']='Failed To Update Record';
    }

    # Get updated Data
    $result = $this->fetch(['id'=>$id]);

    return $result;
  }

#
########################################################################################################
#

  /**
   * Method Name : delete
   * Description : delete a record
   * 
   * @param  int   $id   ID
   * 
   * @return  boolean True / False
   */
  public function delete(int $id)
  {
    # Check id exist
    $fetchId = $this->fetch(['id', $id]);

    # Error check if no record found with given ID
    if(empty($fetchId)) {
      $data['message']='No Record Found With This ID';
    }

    # Initialize variable with false result
    $result = FALSE;

    # Delete data
    $delete = $userDb->delete($this->table, ['id' => $id]);
    # Error check if failed to delete
    if(!$delete) {
      $result = FALSE;
    } else {
      $result = TRUE;
    }

    return $result;
  }
#
########################################################################################################
#
 /**
   * Method Name : search
   * Description : fetch all records based on search data
   * 
   * @param  string $search
   * 
   * @return  array response
   */
  public function search(string $search)
  {
    # Query builder
    $this->db->select('*')->from($this->table);
    $this->db->or_where('user_id LIKE', '%'. $search . '%');
    $this->db->or_where('location_id LIKE', '%'. $search . '%');

    # result query
    $query = $this->db->get()->result();

    # Initialize array
    $data = [];

    # foreach all records
    foreach($query as $item) {
      $data[] = $item;
    }

    return $data;
  }
}
?>