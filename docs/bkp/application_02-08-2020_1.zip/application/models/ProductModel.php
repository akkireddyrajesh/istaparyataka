<?php
if(! defined('BASEPATH')) exit ('No direct script access allowed');

class ProductModel extends CI_Model {

  public function __construct(){
      parent::__construct();
      $this->table = 'products';
      $this->load->model('LibraryModel');
      $this->load->model('CategoryModel');
  }

  /**
   * Method Name : fetch
   * Description : fetch all records based on params
   * 
   * @param  array $params List of params
   * 
   * @return  array response
   */
  public function fetch($params)
  {
    # Query builder
    $this->db->select('*')->from($this->table);

    # id
    if(strlen($params['id']) > 0) $this->db->where('id', $params['id']);
    if(strlen($params['category_id']) > 0) $this->db->where('category_id', $params['category_id']);

    # Pagination
    if( isset($params['limit']) && isset($params['start']) && strlen($params['limit']) > 0 && strlen($params['start']) > 0) $this->db->limit($params['limit'], $params['start']);

    # result query
    $query = $this->db->get()->result();

    # Initialize array
    $data = [];

    # foreach all records
    foreach($query as $item) {
      $item->category = $this->CategoryModel->fetch(['id'=>$item->category_id]);
      $data[] = $item;
    }

    return $data;
  }

#
########################################################################################################
#

  /**
   * Method Name : create
   * Description : create a new record
   * 
   * @param  array $input post body
   * 
   * @return  array response
   */
  public function create(array $input)
  {
    # Upload Image
    if(!empty($input['product_image'])) {
      $uploadUserImage = $this->uploadUserImage($input['product_name'] . 'product_image', $input['product_image']);
    } else {
      $uploadUserImage = "";
    }
    # Create array
    $data=array(
      'category_id'=>$input['category_id'],
      'product_name'=>$input['product_name'],
      'product_code'=>$input['product_code'],
      'product_price'=>$input['product_price'],
      'product_image	'=>$uploadUserImage,
      'status'=>$input['status'],
      'created_dt'=>date('Y-m-d H:i:s'),
      'modified_dt'=>date('Y-m-d H:i:s')
    );

    # Initialize array
    $result = [];

    $insert = $this->db->insert($this->table,$data);
    if($insert) {
      $insertedId = $this->db->insert_id();
      $result = $this->fetch(['id' => $insertedId]);
    } else {
      $result['message'] = 'Failed To Add New Record';
    }
    return $result;
  }

#
########################################################################################################
#

  /**
   * Method Name : update
   * Description : update a existing record
   * 
   * @param  int  $id       ID
   * 
   * @param  array   $input    post body
   * 
   * @return  array response
   */
  public function update(string $id, array $input)
  {

    # Initialize array
    $result = [];

    # Check id exist
    $entity = $this->fetch(['id'=>$id]);

    # Error check if no record found with given ID
    if(empty($entity)) {
      $data['message']='No Record Found With This ID';
    }

    # Upload Image
    if(!empty($input['product_image'])) {
      $uploadUserImage = $this->uploadUserImage($input['product_name'] . 'product_image', $input['product_image']);
    } else {
      $uploadUserImage = "";
    }
    # Create array
    $data=array(
      'category_id'=>$input['category_id'],
      'product_name'=>$input['product_name'],
      'product_code'=>$input['product_code'],
      'product_price'=>$input['product_price'],
      'product_image	'=>$uploadUserImage,
      'status'=>$input['status'],
      'modified_dt'=>date('Y-m-d H:i:s')
    );

    # Update data
    $update = $this->db->where('id',$id)->update($this->table, $data);

    # Error check if failed to update
    if(!$update) {
      $result['message']='Failed To Update Record';
    }

    # Get updated Data
    $result = $this->fetch(['id'=>$id]);

    return $result;
  }

#
########################################################################################################
#

  /**
   * Method Name : delete
   * Description : delete a record
   * 
   * @param  int   $id   ID
   * 
   * @return  boolean True / False
   */
  public function delete(int $id)
  {
    # Check id exist
    $fetchId = $this->fetch(['id', $id]);

    # Error check if no record found with given ID
    if(empty($fetchId)) {
      $data['message']='No Record Found With This ID';
    }

    # Initialize variable with false result
    $result = FALSE;

    # Delete data
    $delete = $userDb->delete($this->table, ['id' => $id]);
    # Error check if failed to delete
    if(!$delete) {
      $result = FALSE;
    } else {
      $result = TRUE;
    }

    return $result;
  }
#
########################################################################################################
#
 /**
   * Method Name : search
   * Description : fetch all records based on search data
   * 
   * @param  string $search
   * 
   * @return  array response
   */
  public function search(string $search)
  {
    # Query builder
    $this->db->select('*')->from($this->table);
    $this->db->or_where('product_name LIKE', '%'. $search . '%');

    # result query
    $query = $this->db->get()->result();

    # Initialize array
    $data = [];

    # foreach all records
    foreach($query as $item) {
      $data[] = $item;
    }

    return $data;
  }

  
#
########################################################################################################
#

  # Move image to folder & return path
  public function uploadUserImage($imgName, $file) 
  {
    # Image
    $base64_string = $file;
    $img_url = $imgName;

    # storage path
    $path = "./uploads".DIRECTORY_SEPARATOR."activity_images";
    if (!is_dir($path)) {
        mkdir($path, 0777, true);
    }

    $url = "http://".$_SERVER['SERVER_NAME'] . DIRECTORY_SEPARATOR . 'meat_mr'  . DIRECTORY_SEPARATOR;
    $path1 = "uploads".DIRECTORY_SEPARATOR."activity_images";
    $filename = rand(1000,9999).'.jpg';
    $filepath = $path. DIRECTORY_SEPARATOR .$img_url.'_'.$filename;
    $final_path = $url.$path1. DIRECTORY_SEPARATOR .$img_url.'_'.$filename;

    # Check whether file exists
    if (file_exists($filepath)) {
      $rand_val = rand(1000,9999);
      $filename1 = $rand_val.'.jpg';
      $filepath = $path.DIRECTORY_SEPARATOR.$img_url.'_'.$filename1;
      $final_path = $url.$path1. DIRECTORY_SEPARATOR .$img_url.'_'.$filename1.'.jpg';
    }

    # open the output file for writing
    $ifp = fopen( $filepath, 'wb' ); 

    # split the string on commas
    $data = explode( ',', $base64_string );

    # we could add validation here with ensuring count( $data ) > 1
    $a = fwrite( $ifp, base64_decode( $data[ 0 ] ) );

    # clean up the file resource
    fclose( $ifp ); 
    return $final_path;
  }
  
}
?>