<?php
if(! defined('BASEPATH')) exit ('No direct script access allowed');

class UsersModel extends CI_Model {

  public function __construct(){
      parent::__construct();
      $this->table = 'users';
      $this->table1 = 'sessions';
      $this->table2 = 'jwt_tokens';
      $this->load->model('LibraryModel');
      $this->load->model('LocationModel');
      $this->load->model('RoleModel');
      $this->load->dbforge();
  }

#
########################################################################################################
#

  /**
   * Method Name : register
   * Description : register a new record
   * 
   * @param  array $input post body
   * 
   * @return  string  Authorization_Token
   */
  public function register(array $input) 
  {
    # user_email - unique check
    $mobile = $this->db->select('*')->from($this->table)->where('user_phone_number', $input['user_phone_number'])->get()->result();
    if(!empty($mobile)) {
      $result['message'] = "User Phone Number Already Exist";
      return $result;
    }

    # Password match
    // if($input['user_password'] !== $input['confirm_password']) {
    //   $result['message'] = "Password does not match!";
    //   return $result;
    // }

    # Create array
    $data=array(
      'user_first_name'=>isset($input['user_first_name']) ? $input['user_first_name'] : '',
      'user_last_name'=>isset($input['user_last_name']) ? $input['user_last_name'] : '',
      'location_id'=>isset($input['location_id']) ? $input['location_id'] : '',
      'user_address'=>isset($input['user_address']) ? $input['user_address'] : '',
      'user_email'=>isset($input['user_email']) ? $input['user_email'] : '',
      'user_phone_number'=>$input['user_phone_number'],
      'role_id'=>$input['role_id'],
      'user_password'=>password_hash('123456', PASSWORD_BCRYPT),
      'pw_algo'=>'PASSWORD_BCRYPT',
      'created_dt'=>date('Y-m-d H:i:s'),
      'modified_dt'=>date('Y-m-d H:i:s')
    );

    # Initialize array
    $result = [];

    # Insert data
    $insert = $this->db->insert($this->table,$data);
    if($insert) {
      $result = true;
    } else {
      $result = false;
    }
      return $result;
  }
 
#
########################################################################################################
# 

  /**
   * Method Name : login
   * Description : Login
   * 
   * @param  array $input post body
   * 
   * @return  string  Authorization_Token
   */
  public function login(array $input) 
  {
    # Get data based on user_phone_number
    $mobile = $this->db->select('*')->from($this->table)->where('user_phone_number', $input['user_phone_number'])->get()->row_array();
    if(empty($mobile)) {
      $result['message'] = "User Phone Number Does Not Exist";
      return $result;
    }

    $verify = password_verify($input['user_password'], $mobile['user_password']);
    if ($verify) {
      # Create a session for a user
      $session = $this->LibraryModel->createSession($mobile['id']);
      if(!empty($session)) {
        # SessionId
        $session_id = $session['session_id'];

        # Create a JWT token
        $token = $this->LibraryModel->createToken($session_id);
        if(!empty($token)) $result['Authorization_Token'] = $token['jwt_token'];
      }
    } else {
      $result['message'] = 'Incorrect password';
    }

    return $result;
  }

public function loginCreate(array $input) {
  $otpNumber = $this->generatePIN(6);
      # Send OTP
      try {
        # Load guzzle library - client purpose
        $this->load->library('guzzle');
        # guzzle client define
        $client     = new GuzzleHttp\Client();
        # Send OTP
        $sendOTPReq = $client->request('GET', 'http://sms.pearlsms.com/public/sms/send?sender=MEATGO&smstype=TRANS&numbers='.$input['user_phone_number'].'&apikey=7751a884e75346448db8a91a671a2c6a&message=Dear Customer, OTP to sign-in/up is :: '.$otpNumber.'');
      } catch (Exception $e) {
        # Send OTP
        $sendOTPReq = $client->request('GET', 'http://sms.pearlsms.com/public/sms/send?sender=MEATGO&smstype=TRANS&numbers='.$input['user_phone_number'].'&apikey=7751a884e75346448db8a91a671a2c6a&message=Dear Customer, OTP to sign-in/up is :: '.$otpNumber.'');
      }
    # Get data based on user_phone_number
    $getExistData = $this->db->select('*')->from($this->table)->where('user_phone_number', $input['user_phone_number'])->get()->row_array();
    if(empty($getExistData)) {
      # Create array
      $data=array(
        'user_first_name'=>isset($input['user_first_name']) ? $input['user_first_name'] : '',
        'user_last_name'=>isset($input['user_last_name']) ? $input['user_last_name'] : '',
        'location_id'=>isset($input['location_id']) ? $input['location_id'] : '',
        'user_address'=>isset($input['user_address']) ? $input['user_address'] : '',
        'user_email'=>isset($input['user_email']) ? $input['user_email'] : '',
        'user_phone_number'=>$input['user_phone_number'],
        'role_id'=>isset($input['role_id']) ? $input['role_id'] : '',
        'user_password'=>password_hash($otpNumber, PASSWORD_BCRYPT),
        'pw_algo'=>'PASSWORD_BCRYPT',
        'created_dt'=>date('Y-m-d H:i:s'),
        'modified_dt'=>date('Y-m-d H:i:s')
      );
      # Initialize array
      $result = [];
      # Insert data
      $insert = $this->db->insert($this->table,$data);
    } else {
      # Create array
      $data=array(
        'user_first_name'=>isset($input['user_first_name']) ? $input['user_first_name'] : '',
        'user_last_name'=>isset($input['user_last_name']) ? $input['user_last_name'] : '',
        'location_id'=>isset($input['location_id']) ? $input['location_id'] : '',
        'user_address'=>isset($input['user_address']) ? $input['user_address'] : '',
        'user_email'=>isset($input['user_email']) ? $input['user_email'] : '',
        'user_phone_number'=>$input['user_phone_number'],
        'role_id'=>isset($input['role_id']) ? $input['role_id'] : '',
        'user_password'=>password_hash($otpNumber, PASSWORD_BCRYPT),
        'pw_algo'=>'PASSWORD_BCRYPT',
        'modified_dt'=>date('Y-m-d H:i:s')
      );

    # Update data
    $update = $this->db->where('user_phone_number',$input['user_phone_number'])->update($this->table,$data);
    }
}

public function generatePIN($digits){
  $i = 0; //counter
  $pin = ""; //our default pin is blank.
  while($i < $digits){
      //generate a random number between 0 and 9.
      $pin .= mt_rand(0, 9);
      $i++;
  }
  return $pin;
}

#
########################################################################################################
# 

  /**
   * Method Name : update
   * Description : update a existing record
   * 
   * @param  int  $id       ID
   * 
   * @param  array   $input    post body
   * 
   * @return  array response
   */
  public function update(int $id, array $input)
  {
    
    # Initialize array
    $result = [];

    # Check id exist
    $entity = $this->db->select('*')->from($this->table)->where('id',$id)->get()->row_array();

    # Error check if no record found with given ID
    if(empty($entity)) {
      $result['message']='No Record Found With This ID';
      return $result;
    }

        # Create array
        $data=array(
          'user_first_name'=>$input['user_first_name'],
          'user_last_name'=>$input['user_last_name'],
          'location_id'=>$input['location_id'],
          'user_address'=>$input['user_address'],
          'user_email'=>$input['user_email'],
          'user_phone_number'=>$input['user_phone_number'],
          'role_id'=>$input['role_id'],
          'user_password'=>password_hash($input['user_password'], PASSWORD_BCRYPT),
          'pw_algo'=>'PASSWORD_BCRYPT',
          'modified_dt'=>date('Y-m-d H:i:s')
        );

    # Update data
    $update = $this->db->where('id',$id)->update($this->table,$data);

    # Error check if failed to update
    if(!$update) {
      $result['message']='Failed To Update Record';
    }

    # Get updated Data
    // $result = $this->db->select('*')->from($this->table)->where('id',$id)->get()->row_array();
    $result = $this->fetch(['id'=>$id]);

    return $result;
  }


  
#
########################################################################################################
# 

  /**
   * Method Name : update
   * Description : update a existing record
   * 
   * @param  int  $id       ID
   * 
   * @param  array   $input    post body
   * 
   * @return  array response
   */
  public function updatePin(int $id, array $input)
  {
    
    # Initialize array
    $result = [];

    # Check id exist
    $entity = $this->db->select('*')->from($this->table)->where('id',$id)->get()->row_array();

    # Error check if no record found with given ID
    if(empty($entity)) {
      $result['message']='No Record Found With This ID';
      return $result;
    }

        # Create array
        $data=array(
          'user_password'=>password_hash($input['user_password'], PASSWORD_BCRYPT),
          'pw_algo'=>'PASSWORD_BCRYPT',
          'modified_dt'=>date('Y-m-d H:i:s')
        );

    # Update data
    $update = $this->db->where('id',$id)->update($this->table,$data);

    # Error check if failed to update
    if(!$update) {
      $result['message']='Failed To Update Record';
    }

    # Get updated Data
    // $result = $this->db->select('*')->from($this->table)->where('id',$id)->get()->row_array();
    $result = $this->fetch(['id'=>$id]);

    return $result;
  }

#
########################################################################################################
# 

  /**
   * Method Name : fetch
   * Description : fetch records based on params
   * 
   * @param  array   $params 
   * 
   * @return  array response
   */
  public function fetch($params)
  {
    # Initialize array
    $result = [];

    # Query builder
    $this->db->select('*')->from('users');
    
    # id
    if(isset($params['id']) && strlen($params['id']) > 0) $this->db->where('id', $params['id']);

    # user_phone_number
    if(isset($params['user_phone_number']) && strlen($params['user_phone_number']) > 0) $this->db->where('user_phone_number', $params['user_phone_number']);

    # user_email
    if(isset($params['user_email']) && strlen($params['user_email']) > 0) $this->db->where('user_email', $params['user_email']);

    # Pagination
    if( isset($params['limit']) && isset($params['start']) && strlen($params['limit']) > 0 && strlen($params['start']) > 0) $this->db->limit($params['limit'], $params['start']);

    # result query
    $query = $this->db->get()->result();
    # foreach all records
    foreach($query as $item) {
      $item->location = $this->LocationModel->fetch(['id'=>$item->location_id]);
      $item->role = $this->RoleModel->fetch(['id'=>$item->role_id]);
      $result[] = $item;
    }


    return $result;
  }

#
########################################################################################################
#

  # Move image to folder & return path
  public function uploadUserImage($imgName, $file) 
  {
    # Image
    $base64_string = $file;
    $img_url = $imgName;

    # storage path
    $path = "./uploads".DIRECTORY_SEPARATOR."user_images";
    if (!is_dir($path)) {
        mkdir($path, 0777, true);
    }

    $url = "http://".$_SERVER['SERVER_NAME'] . DIRECTORY_SEPARATOR . 'meat_mr'  . DIRECTORY_SEPARATOR;
    $path1 = "uploads".DIRECTORY_SEPARATOR."user_images";
    $filename = rand(1000,9999).'.jpg';
    $filepath = $path. DIRECTORY_SEPARATOR .$img_url.'_'.$filename;
    $final_path = $url.$path1. DIRECTORY_SEPARATOR .$img_url.'_'.$filename;

    # Check whether file exists
    if (file_exists($filepath)) {
      $rand_val = rand(1000,9999);
      $filename1 = $rand_val.'.jpg';
      $filepath = $path.DIRECTORY_SEPARATOR.$img_url.'_'.$filename1;
      $final_path = $url.$path1. DIRECTORY_SEPARATOR .$img_url.'_'.$filename1.'.jpg';
    }

    # open the output file for writing
    $ifp = fopen( $filepath, 'wb' ); 

    # split the string on commas
    $data = explode( ',', $base64_string );

    # we could add validation here with ensuring count( $data ) > 1
    $a = fwrite( $ifp, base64_decode( $data[ 0 ] ) );

    # clean up the file resource
    fclose( $ifp ); 
    return $final_path;
  }
  
#
########################################################################################################
#

  /**
   * Method Name : changePassword
   * Description : Change Password
   * 
   * @param   array   $input post body
   * 
   * @return  string  Authorization_Token
   */
  public function changePassword(array $input, array $user, string $token) 
  {
    # Get User Private UUID
    $userData = $this->db->select('*')->from($this->table)->where('id', $user['id'])->get()->row_array() ?? [];
		
    # Verify Password
		$verifyPassword = password_verify( $input['old_password'], $userData['user_password']);
    
    # If password matches create "Session" & "JWT - Token"
    if ($verifyPassword) {

      if(!empty($userData)) {
        # Delete current session
        $deleteSession = $this->db->delete($this->table1, ['user_id' => $user['id'] ]);
  
        # Delete current jwtToken
        $deleteToken = $this->db->delete($this->table2, ['jwt_token' => $token ]);
      }

			# Check whether new password & repeat password is same
			if($input['new_password'] != $input['repeat_password']) {
				# Error Message
				$result['message'] = 'Password Does Not Match!';
				return $result;
			}

			# Force some Body parameters
			$pw_hash = password_hash( $input['new_password'], PASSWORD_BCRYPT);
			$pw_algo = "PASSWORD_BCRYPT";

			# Create array
			$data=array(
				'user_password'=>$pw_hash,
				'pw_algo'=>$pw_algo
			);

			# Initialize array
			$result = [];

			# Update password
			$update = $this->db->where('id',$user['id'])->update($this->table,$data);

			if($update) {
				if(!empty($userData)) {
					# Create a session for a user
          $session = $this->LibraryModel->createSession($user['id']);
          if(!empty($session)) {
            # SessionId
            $session_id = $session['session_id'];
    
            # Create a JWT token
            $token = $this->LibraryModel->createToken($session_id);
            if(!empty($token)) $result['Authorization_Token'] = $token['jwt_token'];
          }
				} else {
					# Error Message
					$result['message'] = 'Failed To Fetch User';
				}
			} else {
				# Error Message
				$result['message'] = 'Failed To Change Password';
			}
		}
    
    return $result ?? [];
  }

#
########################################################################################################
#

  /**
   * Method Name : logout
   * Description : Logout
   * 
   * @param   array   $input post body
   * 
   * @return  boolean
   */
  public function logout(array $user, $token) 
  {
    # Get User Private UUID
    $userData = $this->db->select('*')->from($this->table)->where('id', $user['id'])->get()->row_array() ?? [];
    
    if(!empty($userData)) {
      # Delete current session
      $deleteSession = $this->db->delete('sessions', ['user_id' => $user['id'] ]);

      # Delete current jwtToken
      $deleteToken = $this->db->delete('jwt_tokens', ['jwt_token' => $token ]);
      		
      if( (!$deleteSession) || (!$deleteToken) ) {
        return FALSE;
      } else {
        return TRUE;
      }
    }
  }  
  
}
?>
